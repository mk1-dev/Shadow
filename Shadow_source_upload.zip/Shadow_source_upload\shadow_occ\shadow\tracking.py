from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from shadow_occ.geometry.transforms import apply_transform
from shadow_occ.shadow.labels import ShadowComponent


@dataclass
class TrackState:
    track_id: int
    centroid_global: np.ndarray
    direction_xy: np.ndarray
    age: int
    missed: int = 0


class ShadowTracker:
    """Simple BEV component tracker in global coordinates."""

    def __init__(
        self,
        max_distance_m: float = 3.0,
        min_direction_cos: float = 0.2,
        max_missed: int = 2,
        min_age: int = 2,
    ) -> None:
        self.max_distance_m = max_distance_m
        self.min_direction_cos = min_direction_cos
        self.max_missed = max_missed
        self.min_age = min_age
        self._next_id = 1
        self.tracks: dict[int, TrackState] = {}

    def update(self, components: list[ShadowComponent], ego_to_global: np.ndarray) -> list[ShadowComponent]:
        centroids = np.asarray([c.centroid_xy for c in components], dtype=np.float64)
        if len(centroids):
            zeros = np.zeros((len(centroids), 1), dtype=np.float64)
            centroids_global = apply_transform(np.concatenate([centroids, zeros], axis=1), ego_to_global)[:, :2]
        else:
            centroids_global = np.zeros((0, 2), dtype=np.float64)

        unmatched_tracks = set(self.tracks.keys())
        for idx, component in enumerate(components):
            direction = np.asarray(component.direction_xy, dtype=np.float64)
            track_id = self._match(centroids_global[idx], direction, unmatched_tracks)
            if track_id is None:
                track_id = self._next_id
                self._next_id += 1
                self.tracks[track_id] = TrackState(
                    track_id=track_id,
                    centroid_global=centroids_global[idx],
                    direction_xy=direction,
                    age=0,
                )
            else:
                unmatched_tracks.discard(track_id)

            state = self.tracks[track_id]
            state.centroid_global = 0.6 * state.centroid_global + 0.4 * centroids_global[idx]
            state.direction_xy = _normalize(0.6 * state.direction_xy + 0.4 * direction)
            state.age += 1
            state.missed = 0
            component.track_id = track_id
            component.track_age = state.age
            component.stable = state.age >= self.min_age

        for track_id in unmatched_tracks:
            self.tracks[track_id].missed += 1
        self.tracks = {
            tid: state for tid, state in self.tracks.items() if state.missed <= self.max_missed
        }
        return components

    def _match(
        self,
        centroid_global: np.ndarray,
        direction: np.ndarray,
        candidate_track_ids: set[int],
    ) -> int | None:
        best_id = None
        best_score = float("inf")
        direction = _normalize(direction)
        for track_id in candidate_track_ids:
            state = self.tracks[track_id]
            dist = float(np.linalg.norm(centroid_global - state.centroid_global))
            if dist > self.max_distance_m:
                continue
            cos = float(np.dot(direction, _normalize(state.direction_xy)))
            if abs(cos) < self.min_direction_cos:
                continue
            if dist < best_score:
                best_score = dist
                best_id = track_id
        return best_id


def _normalize(vec: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vec))
    if norm < 1e-6:
        return vec
    return vec / norm
