from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from shadow_occ.config import ShadowConfig


def read_image_bgr(path: str | Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return image


def dark_region_mask(image_bgr: np.ndarray, cfg: ShadowConfig) -> np.ndarray:
    """Find low-illumination image regions using HSV value and light morphology."""
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    adaptive_thr = np.percentile(value, cfg.dark_percentile)
    threshold = min(float(cfg.max_dark_value), float(adaptive_thr))
    mask = (value <= threshold) & (saturation >= cfg.min_saturation)

    kernel_size = max(1, int(cfg.morph_kernel))
    if kernel_size > 1:
        kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
        mask_u8 = mask.astype(np.uint8)
        mask_u8 = cv2.morphologyEx(mask_u8, cv2.MORPH_OPEN, kernel)
        mask_u8 = cv2.morphologyEx(mask_u8, cv2.MORPH_CLOSE, kernel)
        mask = mask_u8.astype(bool)
    return mask
