from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from shadow_occ.geometry.transforms import apply_transform, invert_transform


@dataclass
class CameraCalibration:
    intrinsic: np.ndarray
    sensor_to_ego: np.ndarray
    ego_to_global: np.ndarray
    image_size: tuple[int, int] | None = None

    @property
    def global_to_sensor(self) -> np.ndarray:
        return invert_transform(self.ego_to_global @ self.sensor_to_ego)


def project_points_to_image(
    points: np.ndarray,
    occ_to_global: np.ndarray,
    camera: CameraCalibration,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Project points from an occupancy frame to a nuScenes camera image."""
    if points.size == 0:
        return np.zeros((0, 2)), np.zeros((0,), dtype=bool), np.zeros((0,))

    points_global = apply_transform(points, occ_to_global)
    points_cam = apply_transform(points_global, camera.global_to_sensor)
    depth = points_cam[:, 2]
    valid = depth > 1e-4

    uvw = points_cam @ camera.intrinsic.T
    uv = uvw[:, :2] / np.maximum(uvw[:, 2:3], 1e-6)

    if camera.image_size is not None:
        width, height = camera.image_size
        valid &= (uv[:, 0] >= 0) & (uv[:, 0] < width) & (uv[:, 1] >= 0) & (uv[:, 1] < height)
    return uv, valid, depth


def sample_mask_at_uv(mask: np.ndarray, uv: np.ndarray, valid: np.ndarray) -> np.ndarray:
    out = np.zeros(len(uv), dtype=bool)
    h, w = mask.shape[:2]
    x = np.rint(uv[:, 0]).astype(np.int64)
    y = np.rint(uv[:, 1]).astype(np.int64)
    inside = valid & (x >= 0) & (x < w) & (y >= 0) & (y < h)
    out[inside] = mask[y[inside], x[inside]].astype(bool)
    return out
