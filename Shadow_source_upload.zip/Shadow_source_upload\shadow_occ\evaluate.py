from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any

import numpy as np

try:
    import torch
    from torch.utils.data import DataLoader
except ImportError as exc:  # pragma: no cover
    raise ImportError("Install torch to evaluate the BEVFormer OCC model.") from exc

try:
    import torch.distributed as dist
    from torch.utils.data.distributed import DistributedSampler
except ImportError:  # pragma: no cover
    dist = None
    DistributedSampler = None

from shadow_occ.config import load_config
from shadow_occ.data.bevformer_dataset import NuScenesOccSequenceDataset
from shadow_occ.geometry.bev import BEVGrid
from shadow_occ.metrics.occ3d_metrics import (
    HeightPriorCorrelation,
    Occ3DMetrics,
    pred_semantic_from_logits,
)
from shadow_occ.models.bevformer_occ import build_bevformer_occ_shadow
from shadow_occ.utils.io import ensure_dir, write_json


def main() -> None:
    parser = argparse.ArgumentParser("Evaluate BEVFormer OCC + Shadow model.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--dataroot")
    parser.add_argument("--occ-root")
    parser.add_argument("--output-root")
    parser.add_argument("--shadow-label-root")
    parser.add_argument("--scene", action="append", default=None)
    parser.add_argument("--max-samples", type=int)
    parser.add_argument("--device")
    args = parser.parse_args()

    distributed = _init_distributed()

    overrides: dict[str, Any] = {"data": {}}
    if args.dataroot:
        overrides["data"]["dataroot"] = args.dataroot
    if args.occ_root:
        overrides["data"]["occ_root"] = args.occ_root
    if args.output_root:
        overrides["data"]["output_root"] = args.output_root
    if args.shadow_label_root:
        overrides["data"]["shadow_label_root"] = args.shadow_label_root
    if args.scene:
        overrides["data"]["scene_names"] = args.scene
    if args.max_samples is not None:
        overrides["data"]["max_samples"] = args.max_samples
    cfg = load_config(args.config, overrides=overrides)
    device = _resolve_device(args.device or cfg.train.device, distributed)
    if device.type == "cuda" and not torch.cuda.is_available():
        device = torch.device("cpu")

    dataset = NuScenesOccSequenceDataset(cfg, split="val")
    sampler = DistributedSampler(dataset, shuffle=False) if distributed["distributed"] else None
    loader = DataLoader(
        dataset,
        batch_size=1,
        shuffle=False,
        sampler=sampler,
        num_workers=cfg.train.num_workers,
        pin_memory=device.type == "cuda",
    )
    model = build_bevformer_occ_shadow(cfg).to(device)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(checkpoint["model"])
    model.eval()

    grid = BEVGrid.from_config(cfg.bev)
    metrics = Occ3DMetrics(
        num_classes=cfg.occ.num_classes,
        free_label=cfg.occ.free_label,
        ignore_label=cfg.occ.ignore_label,
        semantic_eval_class_ids=cfg.occ.semantic_eval_class_ids,
        grid=grid,
        z_min=cfg.occ.pc_range[2],
        z_size=cfg.occ.voxel_size[2],
        distance_bins_m=cfg.eval.distance_bins_m,
    )
    height_metrics = HeightPriorCorrelation(
        grid=grid,
        distance_bins_m=cfg.eval.distance_bins_m,
    )

    with torch.no_grad():
        for batch in loader:
            batch = _move_batch(batch, device)
            out = model(batch["images"], batch["ego_to_img"], batch["ego_to_global"])
            semantic_logits = out["semantic_logits"].detach().cpu().numpy()
            occ_logits = out["occ_logits"].detach().cpu().numpy()
            h_shadow = out["H_prior"].detach().cpu().numpy()
            h_occ = batch["H_occ"].detach().cpu().numpy()
            target = batch["semantic_target"].detach().cpu().numpy()
            for idx in range(semantic_logits.shape[0]):
                pred_sem = pred_semantic_from_logits(
                    semantic_logits[idx],
                    occ_logits[idx],
                    free_label=cfg.occ.free_label,
                )
                metrics.update(pred_sem, target[idx])
                height_metrics.update(h_shadow[idx, 0], h_occ[idx, 0])

    _reduce_metric_state(metrics, height_metrics, device, distributed)
    summary = metrics.summarize()
    summary.update(height_metrics.summarize())
    if _is_main_process():
        out_path = ensure_dir(Path(cfg.data.output_root) / "metrics") / "occ3d_metrics.json"
        write_json(out_path, summary)
        print(
            {
                "Occupancy_mIoU": summary["Occupancy_mIoU"],
                "RayIoU": summary["RayIoU"],
                "Semantic_mIoU": summary["Semantic_mIoU"],
                "HeightPrior_corr": summary["HeightPrior_corr"],
            }
        )
        for row in summary["Occupancy_mIoU_by_distance"]:
            print(row)
        for row in summary["RayIoU_by_distance"]:
            print(row)
        for row in summary["HeightPrior_corr_by_distance"]:
            print(row)
        print(f"wrote {out_path}")
    _cleanup_distributed()


def _move_batch(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    return {key: value.to(device, non_blocking=True) if torch.is_tensor(value) else value for key, value in batch.items()}


def _init_distributed() -> dict[str, int | bool]:
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    distributed = world_size > 1
    if distributed:
        if dist is None:
            raise RuntimeError("torch.distributed is required for multi-GPU evaluation.")
        if not dist.is_initialized():
            backend = "nccl" if torch.cuda.is_available() else "gloo"
            dist.init_process_group(backend=backend, init_method="env://")
    return {"distributed": distributed, "world_size": world_size, "rank": rank, "local_rank": local_rank}


def _resolve_device(name: str, distributed: dict[str, int | bool]) -> torch.device:
    if name == "cuda" and torch.cuda.is_available():
        if distributed["distributed"]:
            local_rank = int(distributed["local_rank"])
            torch.cuda.set_device(local_rank)
            return torch.device("cuda", local_rank)
        return torch.device("cuda")
    return torch.device(name)


def _is_main_process() -> bool:
    return int(os.environ.get("RANK", "0")) == 0


def _cleanup_distributed() -> None:
    if dist is not None and dist.is_available() and dist.is_initialized():
        dist.destroy_process_group()


def _reduce_metric_state(metrics: Occ3DMetrics, heights: HeightPriorCorrelation, device: torch.device, distributed: dict[str, int | bool]) -> None:
    if not distributed["distributed"]:
        return

    def reduce_array(array: Any) -> np.ndarray:
        tensor = torch.as_tensor(array, device=device)
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
        return tensor.cpu().numpy()

    metrics.semantic_confusion = reduce_array(metrics.semantic_confusion).astype(np.int64)
    metrics.occupancy_confusion = reduce_array(metrics.occupancy_confusion).astype(np.int64)
    for key, stats in metrics.occupancy_distance_confusion.items():
        metrics.occupancy_distance_confusion[key] = reduce_array(stats).astype(np.int64)
    for key, stats in metrics.ray_stats.items():
        values = reduce_array(np.asarray([stats["intersection"], stats["union"]], dtype=np.int64))
        stats["intersection"], stats["union"] = int(values[0]), int(values[1])
    for stats in heights.stats.values():
        keys = ["n", "sum_x", "sum_y", "sum_x2", "sum_y2", "sum_xy", "sum_abs_err"]
        values = reduce_array(np.asarray([stats[key] for key in keys], dtype=np.float64))
        for key, value in zip(keys, values):
            stats[key] = float(value)


if __name__ == "__main__":
    main()
