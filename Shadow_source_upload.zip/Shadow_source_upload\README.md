# Shadow-OCC

Runnable nuScenes + Occ3D code for testing whether temporal shadow geometry can
provide a weak 3D cue for BEV occupancy, especially at long range.

The implemented main pipeline is:

```text
nuScenes images + calibration + ego pose + LIDAR_TOP
  -> dark-region candidates
  -> ground projection to a shared BEV grid
  -> ego-motion alignment and temporal tracking
  -> root / tip / direction / length / reliability labels
  -> temporal BEVFormer-style encoder
  -> Shadow Geometry Head
  -> U_shadow-gated fusion
  -> binary and semantic occupancy heads
  -> Occ3D-style evaluation
```

This repository contains a self-contained BEVFormer-style implementation. It
does not require `mmcv`, `mmdet3d`, or an external BEVFormer checkout.

## 1. Data boundary

The main experiment keeps pseudo-label construction separate from benchmark
evaluation:

```text
Shadow pseudo labels: nuScenes images + LIDAR_TOP + calibration + ego pose
OCC supervision:      Occ3D labels
Final evaluation:     Occ3D labels
```

The default `data.geometry_source` is `nuscenes_lidar`. The `occ3d` geometry
source is an oracle/diagnostic mode and should not be used as the main result,
because it uses Occ3D geometry while constructing shadow candidates.

Current implementation status:

| Module | Status |
|---|---|
| Dark regions and multi-camera BEV projection | Implemented |
| Ego-motion BEV alignment and temporal fusion | Implemented |
| Component filtering and basic tracking | Implemented |
| Root, tip, direction, length, reliability | Implemented |
| `P_shadow/P_root/P_tip/P_caster/V_shadow/H_prior/U_shadow` | Implemented |
| U_shadow-gated OCC fusion | Implemented |
| OCC and semantic OCC training | Implemented |
| Temporal caster consistency loss | Connected to training |
| Per-range Occupancy mIoU | Implemented |
| Two-GPU training and evaluation | Implemented |
| SAM2/SAM2Long | Not included |
| GroundingDINO | Not included; caster defaults to a root proxy |
| DINOv2 feature consistency | Not included |
| Official Occ3D leaderboard evaluator parity | Not included |

`rendered_shadow_prior` is an approximate fixed-sun BEV ray-cast prior, not a
full differentiable renderer.

## 2. Repository layout

```text
configs/
  default.yaml                 Full Shadow-OCC configuration
  baseline.yaml                Camera-only OCC baseline
  ablation_no_gate.yaml        Disable U_shadow fusion
  ablation_no_temporal.yaml    Disable temporal consistency loss
  oracle_caster.yaml           Annotation-based caster diagnostic upper bound

scripts/
  make_shadow_labels.py        Generate pseudo shadow labels
  train_bevformer_occ.py       Training entry point
  evaluate_bevformer_occ.py    OCC evaluation entry point
  evaluate_shadow_height_corr.py  Shadow geometry precheck

shadow_occ/
  data/                        nuScenes, Occ3D, and LiDAR adapters
  geometry/                    BEV grid, projection, transforms
  shadow/                      Dark masks, labels, tracking, rendering
  models/                      BEVFormer-style model, head, losses
  metrics/                     Occupancy, Semantic, RayIoU, height metrics
  train.py                     Training implementation
  evaluate.py                  Evaluation implementation

tests/                         Synthetic smoke test
```

## 3. Data preparation

### nuScenes

Use the full `v1.0-trainval` nuScenes release:

```text
/data/nuscenes/
  samples/
  sweeps/
  maps/
  v1.0-trainval/
```

The metadata must describe the six cameras and `LIDAR_TOP` sensor.

### Occ3D-nuScenes

Occ3D is required for OCC training and final evaluation. The loader supports:

```text
/data/Occ3D-nuScenes/gts/{scene_name}/{sample_token}/labels.npz
/data/Occ3D-nuScenes/{scene_name}/{sample_token}/labels.npz
/data/Occ3D-nuScenes/{sample_token}/labels.npz
/data/Occ3D-nuScenes/labels/{sample_token}.npz
```

Each `labels.npz` must contain one of:

```text
semantics, semantic, labels, voxel_label
```

Optional visibility arrays are supported: `mask_camera` and `mask_lidar`.
The default label convention is semantic classes `0..16`, free `17`, ignore
`255`.

`annotations.json` is not required by the main pipeline. nuScenes metadata and
Occ3D `labels.npz` are sufficient. Sample annotations are disabled by default.

## 4. Ubuntu installation

Install a PyTorch build compatible with the server CUDA driver, then install
this package:

```bash
cd /public/home/USER/project/Shadow
source /public/home/USER/anaconda3/etc/profile.d/conda.sh
conda activate shadow_occ
pip install -e .
```

Verify the environment:

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available(), torch.cuda.device_count())"
python -m pytest -q
python scripts/train_bevformer_occ.py --smoke
```

For a Slurm job on two RTX 4090 GPUs:

```bash
export CUDA_VISIBLE_DEVICES=0,1
export LD_LIBRARY_PATH=/usr/local/cuda/compat/lib:/usr/local/nvidia/lib:/usr/local/nvidia/lib64:$LD_LIBRARY_PATH
export LD_PRELOAD=$CONDA_PREFIX/lib/libstdc++.so.6
unset PYTORCH_CUDA_ALLOC_CONF
```

Do not use the Windows paths in `default.yaml` on Linux. Pass Linux paths on
the command line as shown below.

## 5. Configuration

Important defaults in `configs/default.yaml`:

```yaml
data:
  version: v1.0-trainval
  geometry_source: nuscenes_lidar
  num_frames: 3
  occ_frame: ego

model:
  use_shadow: true
  use_shadow_fusion: true

train:
  batch_size: 1       # per-GPU batch size under DDP
  num_workers: 0
  epochs: 12
```

The default BEV range is `[-40, 40]m x [-40, 40]m` with `0.4m` resolution,
which gives a `200 x 200` BEV map. The default OCC grid has 16 height bins.

With empty `data.scene_names`, training uses the official nuScenes `train`
scenes and evaluation uses the official `val` scenes. An explicit `--scene`
is useful for debugging, but is not a valid paper split.

## 6. Generate shadow labels

The main path uses LiDAR and images. It does not use Occ3D to create the
pseudo shadow labels.

Small check:

```bash
python scripts/make_shadow_labels.py \
  --config configs/default.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --geometry-source nuscenes_lidar \
  --output-root outputs_quick \
  --scene scene-0001 --max-samples 100 --num-workers 1
```

Full generation:

```bash
python scripts/make_shadow_labels.py \
  --config configs/default.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --geometry-source nuscenes_lidar \
  --output-root outputs --num-workers 2
```

The process pool is scene-level. Each worker loads nuScenes tables and images,
so use 1 or 2 workers when memory is limited; 10 or 15 workers can trigger
OOM kills.

Output:

```text
outputs/shadow_labels/{scene_name}/{sample_token}.npz
outputs/shadow_labels/{scene_name}/{sample_token}.json
outputs/run_config.json
```

The label files contain `shadow_mask`, root/tip/caster heatmaps, direction,
length, reliability, `rendered_shadow_prior`, and component metadata. The
default caster is a root-based proxy, not a GroundingDINO detection.

## 7. Shadow geometry precheck

```bash
python scripts/evaluate_shadow_height_corr.py \
  --config configs/default.yaml \
  --label-root outputs/shadow_labels \
  --output-root outputs
```

This writes `outputs/metrics/shadow_height_corr.json` and reports component
shadow-length versus root-neighborhood height correlation for 0-20m, 20-40m,
40-60m, and all ranges.

For LiDAR-generated labels this is a LiDAR pseudo-height precheck. It is not
the final Occ3D height metric. After model training, use `HeightPrior_corr`
to compare predicted `H_prior` with independently loaded Occ3D `H_occ`.

## 8. Fast training and validation

Create a one-epoch debug configuration:

```bash
cp configs/default.yaml configs/quick.yaml
sed -i 's/^  epochs: 12$/  epochs: 1/' configs/quick.yaml
sed -i 's/^  num_workers: 0$/  num_workers: 2/' configs/quick.yaml
```

Train 100 samples on two GPUs:

```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc_per_node=2 \
  scripts/train_bevformer_occ.py \
  --config configs/quick.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --output-root outputs_quick \
  --shadow-label-root outputs_quick/shadow_labels \
  --scene scene-0001 --max-samples 100 --device cuda
```

The checkpoint is:

```text
outputs_quick/checkpoints/bevformer_occ_shadow_epoch_000.pth
```

Quick functional evaluation on the same scene:

```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc_per_node=2 \
  scripts/evaluate_bevformer_occ.py \
  --config configs/quick.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --output-root outputs_quick \
  --checkpoint outputs_quick/checkpoints/bevformer_occ_shadow_epoch_000.pth \
  --scene scene-0001 --max-samples 20 --device cuda
```

This only verifies the pipeline. It is not a paper result. For a quick
generalization check, remove `--scene` so the official val split is used:

```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc_per_node=2 \
  scripts/evaluate_bevformer_occ.py \
  --config configs/quick.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --output-root outputs_quick \
  --checkpoint outputs_quick/checkpoints/bevformer_occ_shadow_epoch_000.pth \
  --max-samples 200 --device cuda
```

## 9. Formal training and two-GPU evaluation

After the quick run succeeds, generate labels for all required samples and
train with the full configuration:

```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc_per_node=2 \
  scripts/train_bevformer_occ.py \
  --config configs/default.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --output-root outputs \
  --shadow-label-root outputs/shadow_labels \
  --device cuda
```

Evaluate the official val split on two GPUs:

```bash
CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc_per_node=2 \
  scripts/evaluate_bevformer_occ.py \
  --config configs/default.yaml \
  --dataroot /data/nuscenes \
  --occ-root /data/Occ3D-nuScenes \
  --output-root outputs \
  --checkpoint outputs/checkpoints/bevformer_occ_shadow_epoch_011.pth \
  --device cuda
```

The evaluator uses `DistributedSampler`, reduces metric state across ranks,
and only rank 0 writes the result file. Do not launch two independent full
evaluators against the same output directory.

## 10. Metrics

Results are written to `outputs/metrics/occ3d_metrics.json`:

```text
Occupancy_mIoU
Occupancy_mIoU_by_distance
Occupied_IoU
Free_IoU
Semantic_mIoU
Semantic_IoU_by_class
RayIoU
RayIoU_by_distance
HeightPrior_corr
HeightPrior_MAE
HeightPrior_corr_by_distance
```

The paper-facing report should include overall and 0-20m, 20-40m, 40-60m
Occupancy mIoU, RayIoU, Semantic mIoU, and HeightPrior correlation. The local
RayIoU implementation is an ego-centric ray-space metric; use the official
Occ3D evaluator separately for leaderboard-comparable numbers.

## 11. Baseline and ablations

Recommended experiments:

| Experiment | Config | Purpose |
|---|---|---|
| Camera-only baseline | `configs/baseline.yaml` | Remove shadow fusion and shadow losses |
| Full Shadow-OCC | `configs/default.yaml` | Main method |
| No gate | `configs/ablation_no_gate.yaml` | Test the U_shadow gate |
| No temporal loss | `configs/ablation_no_temporal.yaml` | Test temporal consistency |
| Oracle caster | `configs/oracle_caster.yaml` | Diagnostic upper bound only |

Use separate output roots, for example `outputs/baseline`, `outputs/full`,
`outputs/no_gate`, and `outputs/no_temporal`. The key claim is the difference
between Full Shadow-OCC and the camera-only baseline, especially at 40-60m.

## 12. Architecture and losses

Input:

```text
I_(t-2), I_(t-1), I_t
camera projection matrices
ego-to-global transforms
```

Model:

```text
image CNN
  -> BEV queries and camera-projection cross-attention
  -> per-frame BEV features
  -> ego-motion BEV alignment
  -> temporal self-attention
  -> Shadow Geometry Head
  -> U_shadow-gated shadow feature fusion
  -> occupancy decoders
```

Shadow outputs:

```text
P_shadow, P_root, P_tip, P_caster
V_shadow, H_prior, U_shadow, F_shadow
```

Training losses:

```text
L_occ + L_semantic + L_shadow_geometry
      + L_temporal_consistency + L_shadow_motion_smooth
      + L_caster_shadow_geometry + L_render_shadow
      + L_uncertainty_gating
```

The temporal constraint keeps caster bases stable after BEV warping; it does
not force shadow tips and boundaries to be identical across frames.

## 13. Troubleshooting

`No module named shadow_occ`: run from the repository root or execute
`pip install -e .`.

`BrokenProcessPool` or OOM during label generation: reduce `--num-workers` to
1 or 2.

`Occ3D label not found`: check the actual layout with:

```bash
find /data/Occ3D-nuScenes -name labels.npz | head
```

`CUDA unknown error`: check `CUDA_VISIBLE_DEVICES`, `nvidia-smi`, and
`torch.cuda.device_count()`. Do not change `CUDA_VISIBLE_DEVICES` after Python
has started. In Slurm, run inside the allocated GPU job.

Without Occ3D, the project can still generate nuScenes-only shadow labels and
run the length/pseudo-height precheck, but it cannot train the current OCC
target or report Occupancy mIoU, RayIoU, and Semantic mIoU.
