from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from shadow_occ.config import ShadowConfig
from shadow_occ.data.occ3d_loader import Occ3DSample
from shadow_occ.geometry.bev import BEVGrid
from shadow_occ.geometry.projection import CameraCalibration, project_points_to_image, sample_mask_at_uv


@dataclass
class CameraShadowProjection:
    bev_mask: np.ndarray
    confidence: np.ndarray
    projected_points: int
    selected_points: int


def project_dark_ground_to_bev(
    ground_points: np.ndarray,
    dark_mask: np.ndarray,
    occ_to_global: np.ndarray,
    camera: CameraCalibration,
    grid: BEVGrid,
) -> CameraShadowProjection:
    uv, valid, _depth = project_points_to_image(ground_points, occ_to_global, camera)
    selected = sample_mask_at_uv(dark_mask, uv, valid)
    points = ground_points[selected]

    bev = np.zeros(grid.shape, dtype=np.uint8)
    conf = np.zeros(grid.shape, dtype=np.float32)
    if len(points):
        i, j, inside = grid.xy_to_ij(points[:, :2])
        bev[i[inside], j[inside]] = 1
        np.add.at(conf, (i[inside], j[inside]), 1.0)
        conf = np.clip(conf, 0.0, 1.0)

    return CameraShadowProjection(
        bev_mask=bev,
        confidence=conf,
        projected_points=int(np.count_nonzero(valid)),
        selected_points=int(np.count_nonzero(selected)),
    )


def merge_camera_projections(projections: list[CameraShadowProjection]) -> tuple[np.ndarray, np.ndarray]:
    if not projections:
        raise ValueError("No projections to merge.")
    masks = np.stack([p.bev_mask for p in projections], axis=0).astype(bool)
    conf = np.stack([p.confidence for p in projections], axis=0)
    return masks.any(axis=0).astype(np.uint8), np.clip(conf.sum(axis=0), 0.0, 1.0)


def cleanup_bev_mask(mask: np.ndarray, cfg: ShadowConfig) -> np.ndarray:
    kernel_size = max(1, int(cfg.morph_kernel))
    out = mask.astype(np.uint8)
    if kernel_size > 1:
        kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
        out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, kernel)
        out = cv2.morphologyEx(out, cv2.MORPH_OPEN, kernel)
    return (out > 0).astype(np.uint8)


def pseudo_shadow_from_occ_and_images(
    sample: Occ3DSample,
    ground_points: np.ndarray,
    camera_dark_masks: list[tuple[np.ndarray, CameraCalibration]],
    occ_to_global: np.ndarray,
    grid: BEVGrid,
    cfg: ShadowConfig,
) -> tuple[np.ndarray, np.ndarray, dict]:
    projections = [
        project_dark_ground_to_bev(ground_points, dark_mask, occ_to_global, cam, grid)
        for dark_mask, cam in camera_dark_masks
    ]
    if projections:
        mask, confidence = merge_camera_projections(projections)
    else:
        mask = np.zeros(grid.shape, dtype=np.uint8)
        confidence = np.zeros(grid.shape, dtype=np.float32)
    mask = cleanup_bev_mask(mask, cfg)
    meta = {
        "geometry_path": str(getattr(sample, "path", "unknown")),
        "num_ground_points": int(len(ground_points)),
        "camera_projection": [
            {
                "projected_points": p.projected_points,
                "selected_points": p.selected_points,
            }
            for p in projections
        ],
    }
    return mask, confidence, meta
